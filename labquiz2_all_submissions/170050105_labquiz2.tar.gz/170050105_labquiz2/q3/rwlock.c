#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
	zem_init(&(rw->reader),0);
	zem_init(&(rw->writer),0);
	rw->writer_present=0;
	zem_init(&(rw->lock),1);

  //	Write the code for initializing your read-write lock.
}

void ReaderLock(struct read_write_lock *rw)
{
	zem_down(&rw->lock);

	if (!writer_present)
		zem_down(&rw->reader);
	zem_up(&rw->up);
  //	Write the code for aquiring read-write lock by the reader.
}

void ReaderUnlock(struct read_write_lock *rw)
{
	zem_down(&rw->lock);
	zem_up(&rw->up);

	zem_up(&rw_reader);
  //	Write the code for releasing read-write lock by the reader.
}

void WriterLock(struct read_write_lock *rw)
{
	zem_down(&rw->lock);
	zem_up(&rw->up);

	zem_down(&rw->writer);
	rw->writer_present=1
  //	Write the code for aquiring read-write lock by the writer.
}

void WriterUnlock(struct read_write_lock *rw)
{
	zem_down(&rw->lock);
	

	zem_up(&rw_writer);
	rw->writer_present=0;
	zem_up(&rw->up);
  //	Write the code for releasing read-write lock by the writer.
}
