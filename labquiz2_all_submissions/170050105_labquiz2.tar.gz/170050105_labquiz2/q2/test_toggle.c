#include "types.h"
#include "stat.h"
#include "user.h"

int main()
{
  int ret1, ret2;
  int i;
  int parent=0;
  int child1=1;
  int child2=2;
  sem_init(parent,-1);
  sem_init(child1,0);
  sem_init(child2,-1);
  ret1 = fork();
  if(ret1 == 0)
    {
      for(i=0; i < 10; i++) {
      	printf(1, "I am child 1\n");
        sem_up(child2);
        sem_down(child1);
      }
      exit();
    }
  else
    {
      ret2 = fork();
      if(ret2 == 0)
	{
	  for(i=0; i < 10; i++) {
	    printf(1, "I am child 2\n");
      sem_up(parent);
      sem_down(child2);
	  }
	  exit();
	}
      else {
	for(i=0; i < 10; i++) {
	  printf(1, "I am parent\n");
    sem_up(child1);
    sem_down(parent);
	}
	wait();
	wait();
	exit();
      }
    }
}

