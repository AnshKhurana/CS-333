/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

struct sema * semarr[NSEM];
int
sem_init(int index, int val)
{
  // acquire(semarr[index]->lock);
	semarr[index]->semval=val;
	initlock(semarr[index]->lock,"");
  // release(semarr[index]->lock);
  return 0;
}

int
sem_up(int index)
{
  //to be done
  // acquire(semarr[index]->lock);

	semarr[index]->semval++;
	if (semarr[index]->semval >= 0)
		wakeup((void *)index);
  // release(semarr[index]->lock);

  return 0;
}

int
sem_down(int index)
{
  //to be done
  // acquire(semarr[index]->lock);

	semarr[index]->semval--;
	if (semarr[index]->semval < 0)
		sleep((void *)index,semarr[index]->lock);
  // release(semarr[index]->lock);

  return 0;
}

/*----------xv6 sync lab end----------*/
