#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  //	Write the code for initializing your read-write lock.
  zem_init(&(rw->r),1) ;
  zem_init(&(rw->w),1) ;
  zem_init(&(rw->l),1) ;
  rw->rc = 0 ;




}



void ReaderLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the reader.
zem_down(&(rw->w)) ;
zem_down(&(rw->l)) ;
rw->rc++ ;
if(rw->rc==1) {
	zem_down(&(rw->r)) ;
}
zem_up(&(rw->l)) ;
zem_up(&(rw->w)) ;

}

void ReaderUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the reader.
zem_down(&(rw->l));
rw->rc-- ;
if(rw->rc==0) {
	zem_up(&(rw->r)) ;
}
zem_up(&(rw->l)) ;


}

void WriterLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the writer.

zem_down(&(rw->r)) ;
zem_down(&(rw->w)) ;


}

void WriterUnlock(struct read_write_lock *rw)
{
  zem_up(&(rw->w)) ; 
  zem_up(&(rw->r)) ; //	Write the code for releasing read-write lock by the writer.
}
