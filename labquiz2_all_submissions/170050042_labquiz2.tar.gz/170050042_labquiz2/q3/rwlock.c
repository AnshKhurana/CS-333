#include "rwlock.h"
// #include "zemaphore.c"
void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  //	Write the code for initializing your read-write lock.
	rw->readcount=0;
	zem_init(&rw->wr,1);
	zem_init(&rw->m,1);
}

void ReaderLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the reader.
	
	zem_down(&rw->m);
	// printf("start read\n");
	// printf("AAAAAA\n");
	if(rw->readcount==0)
	{
		// printf("read wait started\n");
		zem_down(&rw->wr);
		// printf("read wait over\n");
	}
	rw->readcount++;
	// printf("lol\n");
	// printf("%d\n",rw->wr.val );
	// printf("end read\n");
	zem_up(&rw->m);
	// printf("%d\n", rw->wr.val);
	


}

void ReaderUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the reader.
	zem_down(&rw->m);
	// printf("BBBBB\n");
	rw->readcount--;
	// printf("%d\n", rw->readcount);
	// printf("reader gone\n");
	if(rw->readcount==0) 
		{
			// printf("giving up\n");
			zem_up(&rw->wr);
		}
	zem_up(&rw->m);
	
}

void WriterLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the writer.
	// printf("write wait started\n");
	// printf("%d\n",rw->wr.val );
	zem_down(&rw->wr);
	// printf("%d\n",rw->wr.val );
	// printf("write wait over\n");

}

void WriterUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the writer.

	zem_up(&rw->wr);
	// printf("writer gone\n");
}
