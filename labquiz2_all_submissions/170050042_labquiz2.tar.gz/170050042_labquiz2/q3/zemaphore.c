#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"
pthread_mutex_t m;
pthread_cond_t w;

void zem_init(zem_t *s, int value) {
 pthread_mutex_lock(&m);
  s->val = value;
  pthread_mutex_unlock(&m);
}

void zem_down(zem_t *s) {
	pthread_mutex_lock(&m);
	s->val--;
	if(s->val < 0)
	{
		pthread_cond_wait(&w,&m);
	}
	pthread_mutex_unlock(&m);
}

void zem_up(zem_t *s) {
	pthread_mutex_lock(&m);
	s->val++;
	pthread_cond_signal(&w);
	pthread_mutex_unlock(&m);
}
