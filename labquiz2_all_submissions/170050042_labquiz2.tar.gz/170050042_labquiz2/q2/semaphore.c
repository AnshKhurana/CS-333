/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"



int
sem_init(int index, int val)
{
  //to be done

  sem_arr[index]=val;

  return 0;
}

int
sem_up(int index)
{
  //to be done

	sem_arr[index]++;
	wakeup(&index);

  return 0;
}

int
sem_down(int index)
{
  //to be done

	sem_arr[index]--;
	if(sem_arr[index]<0)
	{
		sleep(&index,s);
	}


  return 0;
}

/*----------xv6 sync lab end----------*/
