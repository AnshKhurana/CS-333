/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

struct proc* chan[1000];
struct spinlock lk;
int wait_proc_ctr;
int a=0;

int
sem_init(int index, int val)
{
  //to be done
	lk.locked=0;
	lk.name="";
	s[index].ctr=val;
	wait_proc_ctr=-1;
	return 0;
}

int
sem_up(int index)
{
  //to be done
	acquire(&lk);
	++s[index].ctr;
	// chan[proc_ctr]=(int)(& blah) + proc_ctr;
	if(wait_proc_ctr>=0){
		wakeup(chan[wait_proc_ctr]);
		--wait_proc_ctr;
	}
	release(&lk);
	return 0;
}

int
sem_down(int index)
{
  //to be done
	acquire(&lk);
	++s[index].ctr;
	if(s[index].ctr<0){
		// cprintf("henlo\n");
		++wait_proc_ctr;
		struct proc *curproc = myproc();
		chan[wait_proc_ctr]=curproc;
		sleep(chan[wait_proc_ctr],&lk);
	}
	release(&lk);
	return 0;
}

/*----------xv6 sync lab end----------*/
