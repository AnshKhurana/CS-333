#include "rwlock.h"

// pthread_mutex_t &lk1=PTHREAD_MUTEX_INITIALIZER;
zem_t lk1;
// zem_init(&&lk1,0);

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  //	Write the code for initializing your read-write lock.

	zem_init(&lk1,1);
	// printf("before la\n");
	zem_down(&lk1);
	// printf("la1\n");

	rw->rc=0;
	zem_init(& rw->rp,1);
	// printf("la2\n");

	zem_init(& rw->wp,1);
	// printf("la3\n");

	zem_up(&lk1);
	// printf("la4\n");

	// printf("after la\n");
}

void ReaderLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the reader.
	zem_down(&lk1);
	zem_down(& rw->wp);
	zem_up(&rw->wp);
	++rw->rc;
	if(rw->rc==1){
		zem_down(&rw->rp);
	}
	zem_up(&lk1);
	
}

void ReaderUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the reader.
	zem_down(&lk1);
	--rw->rc;
	if(rw->rc==0){
		zem_up(&rw->rp);
	}
	zem_up(&lk1);
}

void WriterLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the writer.
	zem_down(&lk1);
	zem_down(& rw->rp);
	zem_up(&rw->rp);
	zem_up(&rw->wp);
	zem_up(&lk1);
}

void WriterUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the writer.
	zem_down(&lk1);
	zem_down(&rw->wp);
	zem_up(&lk1);
}
