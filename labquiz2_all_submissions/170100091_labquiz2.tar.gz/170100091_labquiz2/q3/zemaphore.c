#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"

pthread_mutex_t lk=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;

void zem_init(zem_t *s, int value) {

	pthread_mutex_lock(&lk);
	// printf("before la 1\n");
 	s->ctr=value;
	// printf("after la 1\n");
  pthread_mutex_unlock(&lk);
}

void zem_down(zem_t *s) {
	// printf("ab1\n");
	pthread_mutex_lock(&lk);
	// printf("ab1\n");
	// printf("s->ctr %d\n",s->ctr);
	// printf("ab1\n");
	s->ctr = s->ctr - 1;
	// printf("ab1\n");
	if(s->ctr<0){
		pthread_cond_wait(&cv,&lk);
	}
	// printf("ab1\n");
	pthread_mutex_unlock(&lk);
	// printf("ab1\n");

}

void zem_up(zem_t *s) {
	// printf("ab2\n");
	pthread_mutex_lock(&lk);
	// printf("ab2\n");
	++s->ctr;
	// printf("ab2\n");
	pthread_cond_signal(&cv);
	// printf("ab2\n");
	pthread_mutex_unlock(&lk);
}
