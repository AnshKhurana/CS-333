/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

int
sem_init(int index, int val)
{
  //to be done
	if (index<NSEM || index>=0){
		sema[index]=val;
	}
	initlock(&lk,"");
	sem=0;
  return 0;
}

int
sem_up(int index)
{
  //to be done
	acquire(&lk);
	sema[index]=sema[index]+1;
	apna_wakeup((void*)1);
	release(&lk);
  return 0;
}

int
sem_down(int index)
{
  //to be done
	acquire(&lk);
	sema[index]=sema[index]-1;
	if (sema[index]<0)
	sleep((void*)1,&lk);
	release(&lk);
  return 0;
}

/*----------xv6 sync lab end----------*/
