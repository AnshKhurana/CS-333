#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  //	Write the code for initializing your read-write lock.
	rw->read_wait=rw->write_act=0;
	zem_init(&(rw->zsr),0);
	zem_init(&(rw->zsw),0);
}

void ReaderLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the reader.

	while (rw->write_act){
		zem_down(&(rw->zsr));
	}
	rw->read_wait++;
}

void ReaderUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the reader.
	rw->read_wait--;
	if (rw->read_wait==0){
		zem_up(&(rw->zsw));
	}
}

void WriterLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the writer.
	while (rw->write_act || rw->read_wait>0){
		zem_down(&(rw->zsw));
	}
	rw->write_act=1;
}

void WriterUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the writer.
	rm->write_act=0
	zem_up(&(rw->zsw));
	zem_up(&(rw->zsr));
}
