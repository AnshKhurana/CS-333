/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

struct spinlock slock;
struct semlock
{
	uint arr[NSEM];
}semaph;

int
sem_init(int index, int val)
{
  //to be done
	initlock(&slock,"");
	semaph.arr[index] = val ;
  return 0;
}

int
sem_up(int index)
{
  //to be done
	semaph.arr[index] += 1;
	wakeup((void *)index);
  return 0;
}

int
sem_down(int index)
{
  //to be done
	semaph.arr[index] -= 1;
	int p = semaph.arr[index] ;
	if( p < 0)
	{	
		acquire(&slock);
		sleep((void *)index,&slock);
		release(&slock);
	}
  return 0;
}

/*----------xv6 sync lab end----------*/
