#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"

void zem_init(zem_t *s, int value) {
	pthread_mutex_init(&s->lock,NULL);
	pthread_cond_init(&s->up,NULL);
	pthread_cond_init(&s->down,NULL);
	s->var = value;
  
}

void zem_down(zem_t *s) {
	pthread_mutex_lock(&s->lock);
	s->var--;
	while(s->var < 0)
		pthread_cond_wait(&s->down,&s->lock);
	
	pthread_cond_broadcast(&s->up);
	pthread_mutex_unlock(&s->lock);

}

void zem_up(zem_t *s) {
	pthread_mutex_lock(&s->lock);
	s->var++;
	while(s->var >= 0)
		pthread_cond_wait(&s->up,&s->lock);

	pthread_cond_broadcast(&s->down);
	pthread_mutex_unlock(&s->lock);
}
