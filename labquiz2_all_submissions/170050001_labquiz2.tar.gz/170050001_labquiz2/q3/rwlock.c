#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
    rw->num_reader=0;
    zem_init(&rw->lock,1);
    rw->writing=0;
    rw->writeWait=0;
    zem_init(&rw->readWa,0);
    zem_init(&rw->writeWa,0);
    //	Write the code for initializing your read-write lock.
}

void ReaderLock(struct read_write_lock *rw)
{
    zem_down(&rw->lock);
        rw->num_reader+=1;
    while(rw->writing==1){
        zem_up(&rw->lock);
        zem_down(&rw->readWa);
        zem_down(&rw->lock);
    }
    zem_up(&rw->lock);
  //	Write the code for aquiring read-write lock by the reader.
}

void ReaderUnlock(struct read_write_lock *rw)
{
    zem_down(&rw->lock);
    rw->num_reader=rw->num_reader-1;
    if(rw->num_reader==0 && rw->writeWait>0)
        zem_up(&rw->writeWa);
    zem_up(&rw->lock);
  //	Write the code for releasing read-write lock by the reader.
}

void WriterLock(struct read_write_lock *rw)
{
    zem_down(&rw->lock);
    while(rw->num_reader>0 || rw->writing==1){
        rw->writeWait++;
        zem_up(&rw->lock);
        zem_down(&rw->writeWa);
        zem_down(&rw->lock);
        rw->writeWait--;
    }
    rw->writing++;
    zem_up(&rw->lock);

  //	Write the code for aquiring read-write lock by the writer.
}

void WriterUnlock(struct read_write_lock *rw)
{
    zem_down(&rw->lock);
    rw->writing =0;
    if(rw->num_reader>0)
    {
        for(int i=0;i<rw->num_reader;i++)
            zem_up(&rw->readWa);

    }
    else if(rw->writeWait>0){
        zem_up(&rw->writeWa);
    }
    zem_up(&rw->lock);
  //	Write the code for releasing read-write lock by the writer.
}
