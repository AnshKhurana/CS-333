#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"

void zem_init(zem_t *s, int value) {
    s->val = value;
    pthread_mutex_init(&(s->m1),NULL);
    pthread_cond_init(&(s->c1),NULL);
}

void zem_down(zem_t *s) {
    pthread_mutex_lock(&(s->m1));
    s->val=s->val-1;
    if(s->val<0)
        pthread_cond_wait(&(s->c1),&(s->m1));
    pthread_mutex_unlock(&(s->m1));
}

void zem_up(zem_t *s) {
    pthread_mutex_lock(&(s->m1));
    s->val=s->val+1;
    if(s->val<=0)
        pthread_cond_signal(&(s->c1));
    pthread_mutex_unlock(&(s->m1));
}
