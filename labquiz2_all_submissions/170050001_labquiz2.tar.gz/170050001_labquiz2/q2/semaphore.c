/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"
int
sem_init(int index, int val)
{
    if(index>=NSEM)
    {
        return 0;
    }
    initlock(&s[index].lock,(char*)index);
    s[index].val=val;
    //to be done
  return 0;
}

int
sem_up(int index)
{
     acquire(&s[index].lock);
    if(index>=NSEM)
        return 0;
    s[index].val=s[index].val+1;
    if(s[index].val<=0)
    {
        wake1("as");
        }
    
    release(&s[index].lock);
    return 0;
}   
    //to be done
int
sem_down(int index)
{
  //to be done
    acquire(&s[index].lock);
    if(index>=NSEM)
        return 0;
    s[index].val=s[index].val-1;
    if(s[index].val<0)
    {
        sleep("as",&s[index].lock);
    }
    release(&s[index].lock);
    return 0;
}

/*----------xv6 sync lab end----------*/
