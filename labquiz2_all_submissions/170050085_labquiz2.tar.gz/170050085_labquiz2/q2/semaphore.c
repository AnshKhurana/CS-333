/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

uint sem[NSEM];
int chan;
struct spinlock lk;
initlock(&lk,"");
int
sem_init(int index, int val)
{
	sem[index]=val;
	
  //to be done
  return 0;
}

int
sem_up(int index)
{	acquire(&lk);
	sem[index]++;
	wakeup((void*)&chan);
  //to be done
	release(&lk);
  return 0;
}

int
sem_down(int index)
{	acquire(&lk);
	if(sem[index]>0){
		sem[index]--;
	}
	else{
		sleep((void*)&chan,&lk);
	}
	release(&lk);
  //to be done
  return 0;
}

/*----------xv6 sync lab end----------*/
