#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  
}

void ReaderLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the reader.
	zem_down(&rw->rlock);
	rw->readers++;
	if(rw->readers==1)zem_down(&rw->wait);
	zem_up(&rw->rlock);
}

void ReaderUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the reader.
	zem_down(&rw->rlock);
	rw->readers--;
	if(rw->readers==0)zem_up(&rw->wait);
	zem_up(&rw->rlock);

}

void WriterLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the writer.
	zem_down(&rw->wait);
}

void WriterUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the writer.
	zem_up(&rw->wait);
}
