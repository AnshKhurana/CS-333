/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

struct spinlock locks[NSEM];
struct spinlock lock;
int value[NSEM];

int
sem_init(int index, int val)
{
  lock.cpu=0;
  lock.locked=0;
  acquire(&lock);
  value[index]=val;
  locks[index].cpu=0;
  locks[index].locked=0;
  release(&lock);
  return 0;
}

int
sem_up(int index)
{
  acquire(&lock);
  value[index]++;
  // acquire(&locks[index]);
  if(value[index]>=0)wakeup((void*)100);
  // release(&locks[index]);
  release(&lock);
  return 0;
}

int
sem_down(int index)
{
  acquire(&lock);
  value[index]--;
  // acquire(&locks[index]);
  // while(value[index]<0)sleep((void*)100,&locks[index]);
  while(value[index]<0)sleep((void*)100,&lock);
  // release(&locks[index]);
  release(&lock);
  return 0;
}

/*----------xv6 sync lab end----------*/
