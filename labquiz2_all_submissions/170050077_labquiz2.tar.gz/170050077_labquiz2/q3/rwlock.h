#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <iostream>
#include "zemaphore.h"

struct read_write_lock
{
	zem_t lk, read, write;
	// pthread_mutex_t lk;
	int numReaders, numWriters;
	// pthread_cond_t wait_to_read, wait_to_write;
};

void InitalizeReadWriteLock(struct read_write_lock * rw);
void ReaderLock(struct read_write_lock * rw);
void ReaderUnlock(struct read_write_lock * rw);
void WriterLock(struct read_write_lock * rw);
void WriterUnlock(struct read_write_lock * rw);
