#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  //	Write the code for initializing your read-write lock.
	zem_init(&(rw->lk), 1);
	zem_init(&(rw->read), 0);
	zem_init(&(rw->write), 0);
	rw->numWriters = 0;
	rw->numReaders = 0;
}

void ReaderLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the reader.
  zem_down(&(rw->lk));
  	if (rw->numWriters > 0) {
  		zem_down(&(rw->read));
  	}
  	rw->numReaders++;
  zem_up(&(rw->lk));
}

void ReaderUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the reader.
  zem_down(&(rw->lk));
  	rw->numReaders--;
   // 	if (rw->numReaders == 0) {
  	// 	zem_up(&(rw->read));
  	// }
  zem_up(&(rw->lk));
}

void WriterLock(struct read_write_lock *rw)
{
  //	Write the code for aquiring read-write lock by the writer.
  zem_down(&(rw->lk));
  	if (rw->numWriters > 0 || rw->numReaders > 0) {
  		zem_down(&(rw->write));
  	}
    // zem_down(&(rw->write));
  	rw->numWriters++;
  zem_up(&(rw->lk));
}

void WriterUnlock(struct read_write_lock *rw)
{
  //	Write the code for releasing read-write lock by the writer.
  zem_down(&(rw->lk));
  	rw->numWriters--;
  	// if (rw->numWriters == 0) {
  	// 	zem_up(&(rw->write));
  	// }
  	zem_up(&(rw->write));
  	zem_up(&(rw->read));
  zem_up(&(rw->lk));
}

// #include "rwlock.h"

// void InitalizeReadWriteLock(struct read_write_lock *rw)
// {
//   //	Write the code for initializing your read-write lock.
// 	rw->lk = PTHREAD_MUTEX_INITIALIZER;
// 	rw->numReaders = 0;
// 	rw->numWriters = 0;
// 	rw->wait_to_read = PTHREAD_COND_INITIALIZER;
// 	rw->wait_to_write = PTHREAD_COND_INITIALIZER;
// }

// void ReaderLock(struct read_write_lock *rw)
// {
//   //	Write the code for aquiring read-write lock by the reader.
//   pthread_mutex_lock(&(rw->lk));
//   	if (rw->numWriters > 0) {
//   		pthread_cond_wait(&(rw->wait_to_read), &(rw->lk));
//   	}
//   	rw->numReaders++;
//   pthread_mutex_unlock(&(rw->lk));
// }

// void ReaderUnlock(struct read_write_lock *rw)
// {
//   //	Write the code for releasing read-write lock by the reader.
//   pthread_mutex_lock(&(rw->lk));
//   	rw->numReaders--;
//    	if (rw->numReaders == 0) {
//   		pthread_cond_broadcast(&(rw->wait_to_write));
//   	}
//   	pthread_cond_broadcast(&(rw->wait_to_read));
//   pthread_mutex_unlock(&(rw->lk));
// }

// void WriterLock(struct read_write_lock *rw)
// {
//   //	Write the code for aquiring read-write lock by the writer.
//   pthread_mutex_lock(&(rw->lk));
//   	if (rw->numReaders > 0 || rw->numWriters > 0) {
//   		pthread_cond_wait(&(rw->wait_to_write), &(rw->lk));
//   	}
//   	rw->numWriters++;
//   pthread_mutex_unlock(&(rw->lk));
// }

// void WriterUnlock(struct read_write_lock *rw)
// {
//   //	Write the code for releasing read-write lock by the writer.
//   pthread_mutex_lock(&(rw->lk));
//   	rw->numWriters--;
// 	pthread_cond_broadcast(&(rw->wait_to_read));
// 	pthread_cond_broadcast(&(rw->wait_to_write));
//   pthread_mutex_unlock(&(rw->lk));
// }
