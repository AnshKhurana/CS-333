/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

struct spinlock lock;

int
sem_init(int index, int val)
{
  //to be done
  acquire(&lock);
    int retVal = 0;
    if (index >= 0 && index < NSEM) sem_arr[index] = val;
    else retVal = -1;
  release(&lock);
  return retVal;
}

int
sem_up(int index)
{
  //to be done
  acquire(&lock);
    if(++sem_arr[index] >= 0) {
    	wakeup((void*)index);
    };
  release(&lock);
  return 0;
}

int
sem_down(int index)
{
  //to be done
  acquire(&lock);
    if(--sem_arr[index] < 0) {
    	sleep((void*)index, &lock);
    };
  release(&lock);

  return 0;
}

/*----------xv6 sync lab end----------*/
