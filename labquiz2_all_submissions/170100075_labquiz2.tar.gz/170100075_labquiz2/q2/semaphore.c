/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"


int
sem_init(int index, int val)
{
	//to be done
	acquire(&semalk);
	xchg(&semarray[index],val);
	release(&semalk);
	return 0;
}

int
sem_up(int index)
{
	//to be done
	acquire(&semalk);
	int temp = semarray[index];
	xchg(&semarray[index],temp+1);
	// struct proc *p;
	// acquire(&ptable.lock);
	// for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
	// 	if(p->state == SLEEPING && p->chan == chan){
	// 		p->state = RUNNABLE;
	// 		break;
	// 	}
	// release(&ptable.lock);
	wakeup((void*)&semarray[index]);
	release(&semalk);
	return 0;
}

int
sem_down(int index)
{
	//to be done
	acquire(&semalk);
	int temp = semarray[index];
	xchg(&semarray[index],temp-1);
	if (temp<1) sleep((void*)&semarray[index],&semalk);
	release(&semalk);
	return 0;
}

/*----------xv6 sync lab end----------*/
