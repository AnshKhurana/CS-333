#include "types.h"
#include "stat.h"
#include "user.h"

int main()
{
	int ret1, ret2;
	int i;

	int token=1;
	sem_init(0,1);
	sem_init(1,0);
	sem_init(2,0);
	sem_init(3,0);
	ret1 = fork();
	if(ret1 == 0)
	{
		for(i=0; i < 10; i++) {
			sem_down(0);
			if (token!=1)
			{
				sem_up(0);
				sem_down(1);
				sem_down(0);
			}
			printf(1, "I am child 1\n");
			token=2;
			sem_up(2);
			sem_up(0);
		}
		exit();
	}
	else
	{
		ret2 = fork();
		if(ret2 == 0)
		{
			for(i=0; i < 10; i++) {
				sem_down(0);
				if (token!=2)
				{
					sem_up(0);
					sem_down(2);
					sem_down(0);
				}
				printf(1, "I am child 2\n");
				token=3;
				sem_up(3);
				sem_up(0);
			}
			exit();
		}
		else {
			for(i=0; i < 10; i++) {
				sem_down(0);
				if (token!=3)
				{
					sem_up(0);
					sem_down(3);
					sem_down(0);
				}
				printf(1, "I am parent\n");
				token=1;
				sem_up(1);
				sem_up(0);
			}
			wait();
			wait();
			exit();
		}
	}
}

