#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"

void zem_lock_init(zem_t *s){
	s->m=PTHREAD_MUTEX_INITIALIZER;
	s->c=PTHREAD_COND_INITIALIZER;
}

void zem_init(zem_t *s, int value) {
  zem_lock_init(s);
  pthread_mutex_lock(&s->m);
  s->counter=value;
  pthread_mutex_unlock(&s->m);
}

void zem_down(zem_t *s) {
	pthread_mutex_lock(&s->m);
	int temp=s->counter;
	s->counter=temp-1;
	if (temp<1){
		pthread_cond_wait(&s->c,&s->m);
	}
	pthread_mutex_unlock(&s->m);
}

void zem_up(zem_t *s) {
	pthread_mutex_lock(&s->m);
	int temp=s->counter;
	s->counter=temp+1;
	pthread_cond_signal(&s->c);
	pthread_mutex_unlock(&s->m);
}
