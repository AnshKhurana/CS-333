/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

// #include "pthread.h"

// int sem_arr[NSEM];
// int i;
// for(int i=0; i<NSEM; i++){
// 	sem_arr[i]=0;
// }
int sem_arr[NSEM];
for(int i=0; i<NSEM; i++){
	sem_arr[i]=0;
}
struct spinlock lock;

sem_init(int index, int val)
{
  //to be done
	acquire(&lock);
	if (index<0 || index >=NSEM ) 
		// printf("index out of range\n");
	sem_arr[index]=val;
	release(&lock);
  return 0;
}

int
sem_up(int index)
{
  //to be done
	acquire(&lock);
	sem_arr[index]++;
	wakeup(index, &lock);
	release(&lock);
  return 0;
}

int
sem_down(int index)
{
  //to be done
	acquire(&lock);
	sem_arr[index]--;
	while(sem_arr[index]<0){
		// printf("block this\n");
		sleep(index, &lock);
	}
	release(&lock);
  return 0;
}

/*----------xv6 sync lab end----------*/
