#include "rwlock.h"

void InitalizeReadWriteLock(struct read_write_lock *rw)
{
  	rw->reader_count=0;
  	rw->writer_present=false;
  	rw->reader = PTHREAD_COND_INITIALIZER;
  	rw->writer = PTHREAD_COND_INITIALIZER;
  	rw->m = PTHREAD_MUTEX_INITIALIZER;
}

void ReaderLock(struct read_write_lock *rw)
{
    pthread_mutex_lock(&rw->m);
   
    while(&rw->writer_present)
    	pthread_cond_wait(&rw->reader, &rw->m);
    rw->reader_count++;

  	pthread_mutex_unlock(&rw->m);
}

void ReaderUnlock(struct read_write_lock *rw)
{
  	pthread_mutex_lock(&rw->m);

  	rw->reader_count--;
  	if(&rw->reader_count==0)
  		pthread_cond_signal(&rw->writer);

  	pthread_mutex_unlock(&rw->m);
}

void WriterLock(struct read_write_lock *rw)
{
  	pthread_mutex_lock(&rw->m);

  	rw->writer_present=true;
  	while(&rw->writer_present || &rw->reader_count >0)
  		pthread_cond_wait(&rw->writer, &rw->m);  	

  	pthread_mutex_unlock(&rw->m);
}

void WriterUnlock(struct read_write_lock *rw)
{
  	pthread_mutex_lock(&rw->m);

  	rw->writer_present=false;
	pthread_cond_signal(&rw->reader);
	pthread_cond_signal(&rw->writer);

  	pthread_mutex_unlock(&rw->m);
}
