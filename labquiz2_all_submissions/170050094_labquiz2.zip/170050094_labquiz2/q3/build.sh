gcc test-zem.c zemaphore.c -o test-zem -lpthread
gcc test-toggle.c zemaphore.c -o test-toggle -lpthread
g++ test-rwlock.cpp rwlock.c zemaphore.c -o rwlock -lpthread
