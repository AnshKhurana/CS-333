#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include "zemaphore.h"
pthread_mutex_t lock= PTHREAD_MUTEX_INITIALIZER;
void zem_init(zem_t *s, int value) {
  acquire(&lock);
  	index = *s->index;
	
	zem_arr[index]=value;
	release(&lock);
}

void zem_down(zem_t *s) {
	acquire(&lock);
	index = *s->index;
	zem_arr[index]++;
	wakeup(index, &lock);
	release(&lock);
  // return 0;
}

void zem_up(zem_t *s) {
	acquire(&lock);
	index = *s->index;
	zem_arr[index]--;
	while(sem_arr[index]<0){
		sleep(index, &lock);
	}
	release(&lock);

}
