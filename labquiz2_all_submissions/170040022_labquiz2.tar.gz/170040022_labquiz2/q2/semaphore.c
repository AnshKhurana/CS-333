/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

struct sem semarr[NSEM];

int
sem_init(int index, int val)
{
  //to be done
	acquire(&semarr[index].lock);
	semarr[index].n = val;
	release(&semarr[index].lock);
    return 0;
}

int
sem_up(int index)
{
  //to be done
	acquire(&semarr[index].lock);
	semarr[index].n++;
	wakeup2((void *) semarr[index].n);
	release(&semarr[index].lock);
    return 0;
}

int
sem_down(int index)
{
  //to be done
	acquire(&semarr[index].lock);
	semarr[index].n--;
	if(semarr[index].n < 0)
	{
		sleep((void *) semarr[index].n, &semarr[index].lock);
	}
	release(&semarr[index].lock);
  return 0;
}

/*----------xv6 sync lab end----------*/
